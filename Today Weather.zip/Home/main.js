var usercity = "kurunegala";

//citys in sri lanka

const citysinSrilanka = [
  "Colombo",
  "Kandy",
  "Galle",
  "Negombo",
  "Anuradhapura",
  "Jaffna",
  "Matara",
  "Trincomalee",
  "Batticaloa",
  "Ratnapura",
  "Kurunegala",
  "Badulla",
  "Gampaha",
  "Kalutara",
  "Hambantota",
  "Wattala",
  "Matale",
  "Panadura",
  "Chilaw",
  "Kegalle",
  "Bentota",
  "Mannar",
  "Puttalam",
  "Nuwara Eliya",
  "Dambulla",
  "Beruwala",
  "Avissawella",
  "Vavuniya",
  "Monaragala",
  "Horana",
  "Ampara",
  "Kalmunai",
  "Polonnaruwa",
  "Kataragama",
  "Valvettithurai",
  "Kilinochchi",
  "Tangalle",
  "Bandarawela",
  "Homagama",
  "Ambalangoda",
  "Wellawaya",
  "Embilipitiya",
  "Kuliyapitiya",
  "Hatton",
  "Gampola",
  "Akuressa",
  "Nawalapitiya",
  "Haputale",
  "Sri Jayawardenepura Kotte",
  "Maharagama",
  "Weligama",
  "Balangoda",
  "Point Pedro",
  "Mullaitivu",
  "Wattegama",
  "Narammala",
  "Kandana",

];


// Remove the user's city from the array
citiesinSrilanka = citysinSrilanka.filter(city => city !== usercity);

// Take the first five unique cities from the array
let selectedCities = Array.from(new Set(citiesinSrilanka)).slice(0, 5);

// Output the user's city and selected cities

let city1 = (usercity);
let city2 = (selectedCities[0]);
let city3 = (selectedCities[1]);
let city4 = (selectedCities[2]);
let city5 = (selectedCities[3]);
let city6 = (selectedCities[4]);


// city 1



fetch('https://api.openweathermap.org/data/2.5/weather?q=' + usercity + '&appid=50a7aa80fa492fa92e874d23ad061374')
  .then(response => response.json())
  .then(data => {


      const { name } = data;
      const { icon, description } = data.weather[0];
      const { temp, humidity } = data.main;
      const { speed } = data.wind;

      console.log(name, icon, description, temp, humidity, speed);
  
  document.getElementById('cita').innerHTML = usercity;    

  document.getElementById('icon').src = "https://openweathermap.org/img/wn/" + icon + ".png";
  
  document.getElementById('cloudy').innerHTML = description;
  
  document.getElementById('temp').innerHTML = parseInt(temp - 273) + "°c";
  
  document.getElementById('humidity').innerHTML = humidity + "%";
  
  document.getElementById('wind').innerHTML = speed + "Km/h";

    })

    .catch(err => alert("Can't find anything"));
    
  //city 2
  
fetch('https://api.openweathermap.org/data/2.5/weather?q=' + city2 + '&appid=50a7aa80fa492fa92e874d23ad061374')
  .then(response => response.json())
  .then(data => {


      const { name } = data;
      const { icon, description } = data.weather[0];
      const { temp, humidity } = data.main;
      const { speed } = data.wind;

      console.log(name, icon, description, temp, humidity, speed);
  
  document.getElementById('cita1').innerHTML = city2;    

  document.getElementById('icon1').src = "https://openweathermap.org/img/wn/" + icon + ".png";
  
  document.getElementById('cloudy1').innerHTML = description;
  
  document.getElementById('temp1').innerHTML = parseInt(temp - 273) + "°c";
  
  document.getElementById('humidity1').innerHTML = humidity + "%";
  
  document.getElementById('wind1').innerHTML = speed + "Km/h";

    })

    .catch(err => alert("Can't find anything"));

//city 3

fetch('https://api.openweathermap.org/data/2.5/weather?q=' + city3 + '&appid=50a7aa80fa492fa92e874d23ad061374')
  .then(response => response.json())
  .then(data => {


      const { name } = data;
      const { icon, description } = data.weather[0];
      const { temp, humidity } = data.main;
      const { speed } = data.wind;

      console.log(name, icon, description, temp, humidity, speed);
  
  document.getElementById('cita2').innerHTML = city3;    

  document.getElementById('icon2').src = "https://openweathermap.org/img/wn/" + icon + ".png";
  
  document.getElementById('cloudy2').innerHTML = description;
  
  document.getElementById('temp2').innerHTML = parseInt(temp - 273) + "°c";
  
  document.getElementById('humidity2').innerHTML = humidity + "%";
  
  document.getElementById('wind2').innerHTML = speed + "Km/h";

    })

    .catch(err => alert("Can't find anything"));

  
//city 4

fetch('https://api.openweathermap.org/data/2.5/weather?q=' + city4 + '&appid=50a7aa80fa492fa92e874d23ad061374')
  .then(response => response.json())
  .then(data => {


      const { name } = data;
      const { icon, description } = data.weather[0];
      const { temp, humidity } = data.main;
      const { speed } = data.wind;

      console.log(name, icon, description, temp, humidity, speed);
  
  document.getElementById('cita3').innerHTML = city4;    

  document.getElementById('icon3').src = "https://openweathermap.org/img/wn/" + icon + ".png";
  
  document.getElementById('cloudy3').innerHTML = description;
  
  document.getElementById('temp3').innerHTML = parseInt(temp - 273) + "°c";
  
  document.getElementById('humidity3').innerHTML = humidity + "%";
  
  document.getElementById('wind3').innerHTML = speed + "Km/h";

    })

    .catch(err => alert("Can't find anything"));

//city 5

fetch('https://api.openweathermap.org/data/2.5/weather?q=' + city5 + '&appid=50a7aa80fa492fa92e874d23ad061374')
  .then(response => response.json())
  .then(data => {


      const { name } = data;
      const { icon, description } = data.weather[0];
      const { temp, humidity } = data.main;
      const { speed } = data.wind;

      console.log(name, icon, description, temp, humidity, speed);
  
  document.getElementById('cita4').innerHTML = city5;    

  document.getElementById('icon4').src = "https://openweathermap.org/img/wn/" + icon + ".png";
  
  document.getElementById('cloudy4').innerHTML = description;
  
  document.getElementById('temp4').innerHTML = parseInt(temp - 273) + "°c";
  
  document.getElementById('humidity4').innerHTML = humidity + "%";
  
  document.getElementById('wind4').innerHTML = speed + "Km/h";

    })

    .catch(err => alert("Can't find anything"));

//city 6

fetch('https://api.openweathermap.org/data/2.5/weather?q=' + city6 + '&appid=50a7aa80fa492fa92e874d23ad061374')
  .then(response => response.json())
  .then(data => {


      const { name } = data;
      const { icon, description } = data.weather[0];
      const { temp, humidity } = data.main;
      const { speed } = data.wind;

      console.log(name, icon, description, temp, humidity, speed);
  
  document.getElementById('cita5').innerHTML = city6;    

  document.getElementById('icon5').src = "https://openweathermap.org/img/wn/" + icon + ".png";
  
  document.getElementById('cloudy5').innerHTML = description;
  
  document.getElementById('temp5').innerHTML = parseInt(temp - 273) + "°c";
  
  document.getElementById('humidity5').innerHTML = humidity + "%";
  
  document.getElementById('wind5').innerHTML = speed + "Km/h";

    })

    .catch(err => alert("Can't find anything"));

/* CODED BY THARUSHA Dilshan
 ⇝CONTACT ME : +94772431276 */